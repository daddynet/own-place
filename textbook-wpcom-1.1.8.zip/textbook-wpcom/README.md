
TextBook
===

`TextBook` is a theme for colleges, schools and organizations focused on education. It comes with some interesting features:

* A just right amount of lean, well-commented, modern, HTML5 templates.
* A featured content area to show case recent Posts or Pages.
* A helpful 404 template.
* Custom header options including site logo and custom header background image.
* Licensed under GPLv2 or later. :) Use it to make something cool.


Credits
===

* Flexslider 2.6.4 https://woocommerce.com/flexslider/, (c) 2015 WooThemes, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Theme screenshot uses a CC0 image from Pixabay: https://pixabay.com/en/building-university-college-54347/, [CC0 Creative Commons]
