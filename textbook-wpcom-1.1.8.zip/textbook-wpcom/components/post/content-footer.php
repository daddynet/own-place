	<footer class="entry-footer">
		<?php textbook_entry_footer(); ?>
	</footer><!-- .entry-footer -->