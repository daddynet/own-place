		<div class="entry-meta">
			<?php textbook_posted_on(); ?>
		</div><!-- .entry-meta -->